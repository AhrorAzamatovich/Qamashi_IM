/* Qamashi IM — umumiy frontend */
const cfg = window.QAMASHI_CONFIG || {};
const hasSupabase = typeof window.supabase !== "undefined" && cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes("YOUR-") && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes("YOUR-");
const sb = hasSupabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;

function rootPath() {
  const p = location.pathname;
  return p.includes("/auth/") || p.includes("/dashboard/") || p.includes("/admin/") ? "../" : "";
}
function renderShell() {
  const root = rootPath();
  const header = document.getElementById("site-header");
  if (header) header.innerHTML = `<header class="site-header"><div class="container nav-wrap">
    <a class="brand" href="${root}index.html"><img src="${root}assets/logo.svg" alt=""><span>Qamashi IM<small>Ixtisoslashtirilgan maktab</small></span></a>
    <button class="nav-toggle" aria-label="Menyu">☰</button>
    <nav class="main-nav">
      <a href="${root}index.html">Bosh sahifa</a><a href="${root}about.html">Biz haqimizda</a><a href="${root}news.html">Yangiliklar</a><a href="${root}events.html">Tadbirlar</a><a href="${root}contact.html">Bog‘lanish</a>
      <span id="auth-nav"></span>
    </nav>
  </div></header>`;
  const footer = document.getElementById("site-footer");
  if (footer) footer.innerHTML = `<footer class="site-footer"><div class="container footer-grid">
    <div><a class="brand footer-brand" href="${root}index.html"><img src="${root}assets/logo.svg" alt=""><span>Qamashi IM<small>Ilm • Tarbiya • Natija</small></span></a><p>Qamashi tumani ixtisoslashtirilgan maktabining raqamli axborot portali.</p></div>
    <div><h3>Bo‘limlar</h3><a href="${root}news.html">Yangiliklar</a><a href="${root}events.html">Tadbirlar</a><a href="${root}about.html">Biz haqimizda</a></div>
    <div><h3>Hamjamiyat</h3><a href="${root}auth/register.html">Ro‘yxatdan o‘tish</a><a href="${root}contact.html">Bog‘lanish</a></div>
  </div><div class="footer-bottom"><div class="container">© ${new Date().getFullYear()} Qamashi Ixtisoslashtirilgan Maktabi. Barcha huquqlar himoyalangan.</div></div></footer>`;
  document.querySelector(".nav-toggle")?.addEventListener("click", () => document.querySelector(".main-nav")?.classList.toggle("open"));
}
async function getUser() { if (!sb) return null; const {data:{user}} = await sb.auth.getUser(); return user; }
async function getProfile(userId) { if (!sb) return null; const {data} = await sb.from("profiles").select("*").eq("id", userId).single(); return data; }
async function renderAuthNav() {
  const el = document.getElementById("auth-nav"); if (!el) return;
  const user = await getUser(); const root = rootPath();
  el.innerHTML = user ? `<a class="nav-account" href="${root}dashboard/index.html">Kabinet</a>` : `<a class="nav-login" href="${root}auth/login.html">Kirish</a><a class="btn btn-small btn-primary" href="${root}auth/register.html">Ro‘yxatdan o‘tish</a>`;
}
function postCard(p) {
  const root = rootPath();
  const img = p.cover_url || `${root}assets/placeholder.svg`;
  return `<article class="post-card"><a href="${root}post.html?id=${encodeURIComponent(p.id)}"><img src="${escapeHtml(img)}" alt="${escapeHtml(p.title)}" loading="lazy"></a><div class="post-body"><div class="post-meta">${escapeHtml(p.categories?.name || "Yangilik")} · ${formatDate(p.published_at || p.created_at)}</div><h3><a href="${root}post.html?id=${encodeURIComponent(p.id)}">${escapeHtml(p.title)}</a></h3><p>${escapeHtml(p.excerpt || "")}</p><a class="text-link" href="${root}post.html?id=${encodeURIComponent(p.id)}">Batafsil →</a></div></article>`;
}
async function loadHomePosts() {
  const el = document.getElementById("latest-posts"); if (!el) return;
  if (!sb) { el.innerHTML = demoPosts().map(postCard).join(""); return; }
  const {data,error} = await sb.from("posts").select("*, categories(name)").eq("status","published").order("published_at",{ascending:false}).limit(3);
  el.innerHTML = error || !data?.length ? `<div class="empty-card">Hozircha e’lon qilingan yangiliklar mavjud emas.</div>` : data.map(postCard).join("");
}
async function loadHomeEvents() {
  const el = document.getElementById("upcoming-events"); if (!el || !sb) { if(el) el.innerHTML = demoEvents(); return; }
  const {data} = await sb.from("events").select("*").gte("event_date",new Date().toISOString()).order("event_date").limit(4);
  el.innerHTML = data?.length ? data.map(eventCard).join("") : `<div class="empty-card">Hozircha kelgusi tadbirlar kiritilmagan.</div>`;
}
function eventCard(e) { return `<article class="event-card"><div class="event-date"><strong>${new Date(e.event_date).getDate()}</strong><span>${new Date(e.event_date).toLocaleDateString("uz-UZ",{month:"short"})}</span></div><div><h3>${escapeHtml(e.title)}</h3><p>${escapeHtml(e.description || "")}</p><small>${escapeHtml(e.location || "")}</small></div></article>`; }
async function initNewsPage() {
  const cat = document.getElementById("category-filter"), grid = document.getElementById("news-grid");
  if (!sb) { grid.innerHTML = demoPosts().map(postCard).join(""); return; }
  const {data: cats} = await sb.from("categories").select("*").order("name"); (cats||[]).forEach(c=>cat.insertAdjacentHTML("beforeend",`<option value="${c.id}">${escapeHtml(c.name)}</option>`));
  async function fetchPosts(){ let q=sb.from("posts").select("*, categories(name)").eq("status","published").order("published_at",{ascending:false}); if(cat.value) q=q.eq("category_id",cat.value); const term=document.getElementById("search-input").value.trim(); if(term) q=q.or(`title.ilike.%${term}%,excerpt.ilike.%${term}%`); const {data}=await q; grid.innerHTML=data?.length?data.map(postCard).join(""):`<div class="empty-card">Mos yangilik topilmadi.</div>`; }
  cat.addEventListener("change",fetchPosts); document.getElementById("search-input").addEventListener("input",debounce(fetchPosts,350)); fetchPosts();
}
async function initEventsPage(){ const el=document.getElementById("events-page"); if(!sb){el.innerHTML=demoEvents();return;} const {data}=await sb.from("events").select("*").order("event_date",{ascending:false}); el.innerHTML=data?.length?data.map(eventCard).join(""):`<div class="empty-card">Tadbirlar hali kiritilmagan.</div>`; }
async function loadPostDetail(){
  const el=document.getElementById("post-detail"), id=new URLSearchParams(location.search).get("id");
  if(!id){el.innerHTML="<div class='empty-card'>Maqola topilmadi.</div>";return;}
  if(!sb){const p=demoPosts().find(x=>String(x.id)===id)||demoPosts()[0]; el.innerHTML=postArticle(p); return;}
  const {data,error}=await sb.from("posts").select("*, categories(name), profiles(full_name)").eq("id",id).eq("status","published").single();
  if(error||!data){el.innerHTML="<div class='empty-card'>Maqola topilmadi.</div>";return;}
  await sb.rpc("increment_post_views",{post_id:id}); el.innerHTML=postArticle(data);
}
function postArticle(p){return `<article class="article"><div class="post-meta">${escapeHtml(p.categories?.name||"Yangilik")} · ${formatDate(p.published_at||p.created_at)} · 👁 ${p.views||0}</div><h1>${escapeHtml(p.title)}</h1><p class="lead">${escapeHtml(p.excerpt||"")}</p>${p.cover_url?`<img class="article-cover" src="${escapeHtml(p.cover_url)}" alt="">`:""}<div class="article-content">${simpleMarkdown(p.content||"")}</div><div class="author-box"><strong>Muallif:</strong> ${escapeHtml(p.profiles?.full_name||"Qamashi IM foydalanuvchisi")}</div></article>`}
async function initLogin(){document.getElementById("login-form").addEventListener("submit",async e=>{e.preventDefault();const m=document.getElementById("form-message");if(!sb){m.textContent="Avval js/config.js faylida Supabase sozlamalarini kiriting.";return;}const {error}=await sb.auth.signInWithPassword({email:email.value,password:password.value});if(error){m.textContent=error.message;return;}location.href="../dashboard/index.html";});}
async function initRegister(){document.getElementById("register-form").addEventListener("submit",async e=>{e.preventDefault();const m=document.getElementById("form-message");if(!sb){m.textContent="Avval js/config.js faylida Supabase sozlamalarini kiriting.";return;}const {data,error}=await sb.auth.signUp({email:email.value,password:password.value,options:{data:{full_name:document.getElementById("full-name").value,phone:document.getElementById("phone").value}}});if(error){m.textContent=error.message;return;}m.textContent=data.session?"Akkaunt yaratildi.":"Emailingizni tasdiqlang, so‘ng kiring.";});}
async function requireUser(){const u=await getUser();if(!u){location.href=`${rootPath()}auth/login.html`;return null;}return u;}
async function initDashboard(){const u=await requireUser();if(!u)return;const p=await getProfile(u.id);document.getElementById("welcome-title").textContent=`Xush kelibsiz, ${p?.full_name||u.email}`;document.getElementById("logout-btn").onclick=logout;const {data}=await sb.from("posts").select("*").eq("author_id",u.id).order("created_at",{ascending:false}).limit(3);const {count}=await sb.from("posts").select("*",{count:"exact",head:true}).eq("author_id",u.id);document.getElementById("my-stats").innerHTML=`<div class="stat"><strong>${count||0}</strong><span>Jami post</span></div><div class="stat"><strong>${(data||[]).filter(x=>x.status==="published").length}</strong><span>Nashr qilingan</span></div><div class="stat"><strong>${(data||[]).filter(x=>x.status==="pending").length}</strong><span>Kutilmoqda</span></div>`;document.getElementById("dashboard-posts").innerHTML=data?.length?data.map(p=>`<div class="mini-post"><span class="status status-${p.status}">${statusText(p.status)}</span><h3>${escapeHtml(p.title)}</h3><small>${formatDate(p.created_at)}</small></div>`).join(""):`<div class="empty-card">Hali post yubormagansiz.</div>`;}
async function initCreatePost(){const u=await requireUser();if(!u)return;const {data:cats}=await sb.from("categories").select("*").order("name");category.innerHTML=(cats||[]).map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join("");document.getElementById("post-form").addEventListener("submit",async e=>{e.preventDefault();const m=document.getElementById("form-message");let cover_url=null;const file=document.getElementById("cover").files[0];if(file){const ext=file.name.split(".").pop().toLowerCase();const path=`${u.id}/${Date.now()}.${ext}`;const up=await sb.storage.from("post-images").upload(path,file,{upsert:false});if(up.error){m.textContent=up.error.message;return;}cover_url=sb.storage.from("post-images").getPublicUrl(path).data.publicUrl;}const payload={author_id:u.id,title:title.value.trim(),excerpt:excerpt.value.trim(),content:content.value.trim(),category_id:category.value,cover_url,status:"pending"};const {error}=await sb.from("posts").insert(payload);m.textContent=error?error.message:"Post moderator tekshiruviga yuborildi.";if(!error)e.target.reset();});}
async function initMyPosts(){const u=await requireUser();if(!u)return;const el=document.getElementById("my-posts-list");const {data}=await sb.from("posts").select("*, categories(name)").eq("author_id",u.id).order("created_at",{ascending:false});el.innerHTML=data?.length?`<table><thead><tr><th>Sarlavha</th><th>Kategoriya</th><th>Holat</th><th>Sana</th></tr></thead><tbody>${data.map(p=>`<tr><td>${escapeHtml(p.title)}</td><td>${escapeHtml(p.categories?.name||"")}</td><td><span class="status status-${p.status}">${statusText(p.status)}</span></td><td>${formatDate(p.created_at)}</td></tr>`).join("")}</tbody></table>`:`<div class="empty-card">Hali post yuborilmagan.</div>`;}
async function initAdmin(){const u=await requireUser();if(!u)return;const p=await getProfile(u.id);if(!["admin","moderator"].includes(p?.role)){document.getElementById("pending-posts").innerHTML="<div class='empty-card'>Sizda moderator huquqi yo‘q.</div>";return;}const {data}=await sb.from("posts").select("*, categories(name), profiles(full_name)").eq("status","pending").order("created_at");document.getElementById("admin-stats").innerHTML=`<div class="stat"><strong>${data?.length||0}</strong><span>Kutilayotgan post</span></div>`;document.getElementById("pending-posts").innerHTML=data?.length?data.map(p=>`<div class="review-card"><div><span class="status status-pending">Kutilmoqda</span><h3>${escapeHtml(p.title)}</h3><p>${escapeHtml(p.excerpt||"")}</p><small>Muallif: ${escapeHtml(p.profiles?.full_name||"")} · ${formatDate(p.created_at)}</small></div><div class="review-actions"><button class="btn btn-primary" onclick="reviewPost('${p.id}','published')">✓ Nashr</button><button class="btn btn-danger" onclick="reviewPost('${p.id}','rejected')">Rad etish</button></div></div>`).join(""):`<div class="empty-card">Kutilayotgan postlar yo‘q.</div>`;}
async function reviewPost(id,status){const {error}=await sb.from("posts").update({status,published_at:status==="published"?new Date().toISOString():null}).eq("id",id);if(error)alert(error.message);else location.reload();}
async function logout(){if(sb)await sb.auth.signOut();location.href=`${rootPath()}index.html`;}
function statusText(s){return {pending:"Kutilmoqda",published:"Nashr qilingan",rejected:"Rad etilgan",draft:"Qoralama"}[s]||s;}
function formatDate(d){return d?new Date(d).toLocaleDateString("uz-UZ",{year:"numeric",month:"long",day:"numeric"}):"";}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function simpleMarkdown(s){return escapeHtml(s).replace(/\n\n/g,"</p><p>").replace(/\n/g,"<br>");}
function debounce(fn,ms){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}}
function demoPosts(){return[{id:"demo-1",title:"Qamashi Ixtisoslashtirilgan Maktabining yangi axborot portali",excerpt:"Maktab yangiliklari va tadbirlarini yagona raqamli platformada kuzatib boring.",content:"Portal ishga tushirildi.",created_at:"2026-09-28",published_at:"2026-09-28",views:0,categories:{name:"Yangilik"}}];}
function demoEvents(){return `<div class="empty-card">Supabase sozlangach, tadbirlar bazadan avtomatik ko‘rinadi.</div>`;}
document.addEventListener("DOMContentLoaded",()=>{renderShell();renderAuthNav();});
