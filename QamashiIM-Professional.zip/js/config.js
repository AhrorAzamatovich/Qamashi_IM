/*
  SUPABASE SOZLAMALARI
  1) Supabase loyihangizni yarating.
  2) Project URL va Publishable/Anon key ni shu yerga yozing.
  3) Bu faylga service_role/secret key yozmang.
*/
window.QAMASHI_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-PUBLISHABLE-OR-ANON-KEY"
};