Bu papkaga keyinchalik maktabning haqiqiy logo/fotolarini qo'yishingiz mumkin.
